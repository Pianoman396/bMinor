<?
require_once(__DIR__.'/dbconfig.php');

class User {

	public function __construct(){
		// $dom = new DOMDocument();

	}
	public function __destruct(){

	}

	public function create(){
		// $validator = new Validator($userdata); // $_POST data

		if(isset($_POST['send'])){
			$submit = $_POST['send'];
   			$name = $_POST['user'];
   			$surname = $_POST['surname'];
   			$email = $_POST['email'];
   			$username = $_POST['username'];
   			$password = md5($_POST['pswd']);

   			$postVars = ['user' => '','surname' => '' ,'email' => '','username' => '','pswd' =>''];
   			// $postVars = ['fields'=>['user' => '','surname' => '' ,'email' => '','username' => '','pswd' =>''],'errors'=>''];


   			foreach($postVars as $name => $value):
    			if(isset($_POST[$name])):
     			   $postVars[$name] = $_POST[$name];
   				endif;
			endforeach;

   			$redirect_to = "{$_SERVER['REQUEST_SCHEME']}"."://"."{$_SERVER['HTTP_HOST']}/register/index.php";
   			// echo $redirect_to;

   			if($name == "" || $surname == "" || $email == "" || $username == "" || $password == ""){
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, htmlspecialchars($redirect_to));
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $postVars);
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$response = curl_exec($ch);
				echo $response;
				curl_close($ch);

				}else{
					mysql_query(query);
					mysql_close($connect);
				}

		}

	}
	public function read(){



	}

	public function update(){

	}

	public function delete(){

	}

}

class Vaidator{
	public $data;

	function __construct($data){
		$this->$data = $data;
	}

	public function name($name) {
		// name validation
		$errors = [];
		$validated = false;
		if(isset($name) && $name):
			// katarvum a validacian
			$regex = '/^asdzxc$/';
			$validated = true;

		else:
			// Empty field
		endif;

		if(empty($errors)):
			return true;
		else:
			return array(['errors']=>$errors);
		endif;
	}
	public function username() {
		// username validation
	}

	public function email() {
		// email validation
	}

	public function is_all_validated() {
		$name_validation = $this->name($data['name']);
		$email_validation = $this->email($data['email']);

		if(empty($name_validation)):

		endif;
	}


}