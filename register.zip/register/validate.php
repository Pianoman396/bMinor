<?php
ini_set('display_errors', '1');
error_reporting(E_ALL);
require_once(__DIR__.'/classes.php');

//ini_set('display_errors', E_ALL);
/**
* 	Class for connect a Datebase an get a data
*/

/**
* 	Class get a user data in form and
*/

$usr1 = new User(); // $userdata set atribute
$usr1->create();